#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const char* serverUrl = "http://192.168.31.79:5000/api/sensor-data";
const char* sensorInfoUrl = "http://192.168.31.79:5000/api/sensors";
const char* token = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY4NGYxNTQyNmYzNzg1MmZlMGM4MTdkZiIsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzUwMTQyODU3fQ.CsaoQ5GxHzDcNoNLB8u1ed-an_6X865Lrj2ZxreIVwM";

const char* fieldId = "685185afdf8c0ccb75a2d93a";
const char* sensorName = "Сенсор №1";

float sensorLat = 0;
float sensorLng = 0;

void setup() {
  Serial.begin(115200);
  delay(1000);
  WiFi.begin(ssid, password);

  Serial.println("Connecting to WiFi...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected to WiFi");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    String fullUrl = String(sensorInfoUrl) + "?fieldId=" + fieldId;
    http.begin(fullUrl);
    http.addHeader("Authorization", token);

    int httpCode = http.GET();
    if (httpCode == 200) {
      String payload = http.getString();
      DynamicJsonDocument doc(2048);
      deserializeJson(doc, payload);

      JsonArray sensors = doc.as<JsonArray>();
      for (JsonObject sensor : sensors) {
        if (sensor["name"] == sensorName) {
          float lat = sensor["location"]["lat"];
          float lng = sensor["location"]["lng"];

          if (lat != 0 && lng != 0) {
            HTTPClient postHttp;
            postHttp.begin(serverUrl);
            postHttp.addHeader("Content-Type", "application/json");

            DynamicJsonDocument dataDoc(512);
            dataDoc["fieldId"] = fieldId;
            dataDoc["sensorName"] = sensorName;

            JsonObject location = dataDoc.createNestedObject("location");
            location["lat"] = lat;
            location["lng"] = lng;

            JsonObject data = dataDoc.createNestedObject("data");
            data["temperature"] = random(10, 30);
            data["moisture"] = random(20, 60);

            JsonObject npk = data.createNestedObject("npk");
            npk["nitrogen"] = random(10, 40);
            npk["phosphorus"] = random(5, 30);
            npk["potassium"] = random(5, 30);

            String json;
            serializeJson(dataDoc, json);
            int code = postHttp.POST(json);

            if (code > 0) {
              Serial.println("✅ Дані надіслано успішно!");
            } else {
              Serial.print("❌ Помилка надсилання: ");
              Serial.println(code);
            }

            postHttp.end();
          } else {
            Serial.println("❌ Координати не знайдено");
          }

          break;
        }
      }
    } else {
      Serial.print("❌ Помилка отримання сенсорів: ");
      Serial.println(httpCode);
    }

    http.end();
  } else {
    Serial.println("WiFi disconnected");
  }

  delay(10000);  // 10 секунд
}