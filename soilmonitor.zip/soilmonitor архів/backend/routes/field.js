import express from 'express';
import Field from '../models/Field.js';
import { authenticate } from '../middleware/auth.js';
import multer from 'multer';
import fs from 'fs';

const router = express.Router();

// uploads folder
const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) =>
    cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage });

// отримуємо всі поля користувача
router.get('/', authenticate, async (req, res) => {
  const fields = await Field.find({ owner: req.user.id });
  res.json(fields);
});

// додавання поля
router.post('/', authenticate, async (req, res) => {
  try {
    const newField = new Field({ ...req.body, owner: req.user.id });
    await newField.save();
    res.status(201).json(newField);
  } catch (err) {
    res.status(400).json({ error: 'Помилка при створенні поля' });
  }
});

// перевірка стану
router.get('/with-stats', authenticate, async (req, res) => {
  try {
    const fields = await Field.find({ owner: req.user.id });
    const enrichedFields = await Promise.all(fields.map(async (field) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const readings = await SensorReading.find({
        fieldId: field._id,
        timestamp: { $gte: today }
      });

      const temperatureValues = readings.map(r => r.data.temperature).filter(v => v != null);
      const moistureValues = readings.map(r => r.data.moisture).filter(v => v != null);
      const npkValues = readings
        .map(r => {
          const { nitrogen, phosphorus, potassium } = r.data.npk || {};
          return nitrogen && phosphorus && potassium
            ? (nitrogen + phosphorus + potassium) / 3
            : null;
        })
        .filter(v => v != null);

      const avg = (arr) => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null;

      const avgTemperature = avg(temperatureValues);
      const avgHumidity = avg(moistureValues);
      const avgNPK = avg(npkValues);

      let status = 'нормальний';
      if (
        (avgTemperature != null && (avgTemperature < 5 || avgTemperature > 35)) ||
        (avgHumidity != null && (avgHumidity < 30 || avgHumidity > 80)) ||
        (avgNPK != null && avgNPK < 20)
      ) {
        status = 'критичний';
      } else if (
        (avgTemperature != null && (avgTemperature < 10 || avgTemperature > 30)) ||
        (avgHumidity != null && (avgHumidity < 40 || avgHumidity > 70)) ||
        (avgNPK != null && avgNPK < 40)
      ) {
        status = 'потребує уваги';
      }

      return {
        ...field.toObject(),
        avgTemperature,
        avgHumidity,
        avgNPK,
        status
      };
    }));

    res.json(enrichedFields);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Не вдалося отримати поля з показниками' });
  }
});

// видалити поле
router.delete('/:id', authenticate, async (req, res) => {
  await Field.deleteOne({ _id: req.params.id, owner: req.user.id });
  res.status(204).send();
});

// додати нотатку
router.post('/:id/note', authenticate, async (req, res) => {
  const { text } = req.body;
  const field = await Field.findById(req.params.id);
  if (field.owner.toString() !== req.user.id) return res.sendStatus(403);
  field.notes.push({ text });
  await field.save();
  res.status(201).json(field.notes);
});

// отримати всі нотатки
router.get('/:id/notes', authenticate, async (req, res) => {
  const field = await Field.findById(req.params.id);
  if (field.owner.toString() !== req.user.id) return res.sendStatus(403);
  res.json(field.notes);
});

// редагувати нотатку
router.put('/:fieldId/notes/:noteId', authenticate, async (req, res) => {
  const field = await Field.findById(req.params.fieldId);
  if (!field || field.owner.toString() !== req.user.id) return res.sendStatus(403);
  const note = field.notes.id(req.params.noteId);
  if (!note) return res.status(404).json({ error: 'Нотатку не знайдено' });
  note.text = req.body.text;
  await field.save();
  res.json(field.notes);
});

// видалити нотатку
router.delete('/:fieldId/notes/:noteId', authenticate, async (req, res) => {
  const field = await Field.findById(req.params.fieldId);
  if (!field || field.owner.toString() !== req.user.id) return res.sendStatus(403);
  field.notes = field.notes.filter(note => note._id.toString() !== req.params.noteId);
  await field.save();
  res.sendStatus(204);
});

// завантаження документа
router.post('/:id/upload', authenticate, upload.single('file'), async (req, res) => {
  const field = await Field.findById(req.params.id);
  if (field.owner.toString() !== req.user.id) return res.sendStatus(403);
  const url = `/uploads/${req.file.filename}`;
  field.documents.push({ filename: req.file.originalname, url });
  await field.save();
  res.status(201).json(field.documents);
});

// отримання документів
router.get('/:id/documents', authenticate, async (req, res) => {
  const field = await Field.findById(req.params.id);
  if (field.owner.toString() !== req.user.id) return res.sendStatus(403);
  res.json(field.documents);
});

// видалення документу
router.delete('/:fieldId/documents/:docId', authenticate, async (req, res) => {
  const field = await Field.findById(req.params.fieldId);
  if (!field || field.owner.toString() !== req.user.id) return res.sendStatus(403);
  field.documents = field.documents.filter(doc => doc._id.toString() !== req.params.docId);
  await field.save();
  res.sendStatus(204);
});

// отримати 1 поле
router.get('/:id', authenticate, async (req, res) => {
  const field = await Field.findById(req.params.id);
  if (!field) return res.status(404).json({ error: 'Поле не знайдено' });
  res.json(field);
});

// оновлення поля
router.put('/:id', authenticate, async (req, res) => {
  try {
    const field = await Field.findOneAndUpdate(
      { _id: req.params.id, owner: req.user.id },
      req.body,
      { new: true }
    );
    if (!field) return res.status(404).json({ error: 'Поле не знайдено або доступ заборонено' });
    res.json(field);
  } catch (err) {
    console.error('Помилка при оновленні поля:', err);
    res.status(500).json({ error: 'Помилка при оновленні поля' });
  }
});

import SensorReading from '../models/SensorReading.js';

export default router;