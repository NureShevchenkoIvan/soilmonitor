import express from 'express';
import Sensor from '../models/Sensor.js';
import Field from '../models/Field.js';
import { authenticate } from '../middleware/auth.js';
import inside from 'point-in-polygon';

const router = express.Router();

// Отримати всі сенсори для поля
router.get('/', authenticate, async (req, res) => {
  const { fieldId } = req.query;

  let fields = [];
  if (fieldId) {
    fields = [fieldId];
  } else {
    const userFields = await Field.find({ owner: req.user.id }, '_id');
    fields = userFields.map(f => f._id);
  }

  const sensors = await Sensor.find({ fieldId: { $in: fields } });
  res.json(sensors);
});


// додати новий сенсор
router.post('/', authenticate, async (req, res) => {
  try {
    const { fieldId, name, location } = req.body;

    if (!fieldId || !location?.lat || !location?.lng) {
      return res.status(400).json({ error: 'Невірні вхідні дані' });
    }

    const field = await Field.findById(fieldId);
    if (!field) return res.status(404).json({ error: 'Поле не знайдено' });

    const isInside = inside(
      [location.lat, location.lng],
      field.boundary.map(coord => [coord.lat, coord.lng])
    );

    if (!isInside) {
      return res.status(400).json({ error: 'Сенсор повинен бути в межах поля' });
    }

    const sensor = new Sensor({
      fieldId,
      name: name || `Sensor-${Date.now()}`,
      location,
      timestamp: new Date()
    });

    await sensor.save();
    res.status(201).json(sensor);
  } catch (err) {
    console.error('Sensor creation error:', err);
    res.status(500).json({ error: 'Помилка створення сенсора' });
  }
});

// оновлення сенсора
router.put('/:id', authenticate, async (req, res) => {
  try {
    const updated = await Sensor.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: 'Не вдалося оновити сенсор' });
  }
});

// видалення сенсора
router.delete('/:id', authenticate, async (req, res) => {
  try {
    await Sensor.findByIdAndDelete(req.params.id);
    res.json({ message: 'Сенсор видалено' });
  } catch (err) {
    res.status(400).json({ error: 'Помилка видалення' });
  }
});

export default router;