import express from 'express';
import SensorReading from '../models/SensorReading.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// додавання нового зчитування
router.post('/', async (req, res) => {
  try {
    const reading = new SensorReading(req.body);
    await reading.save();
    res.status(201).json({ message: 'Дані збережено' });
  } catch (err) {
    res.status(400).json({ error: 'Помилка збереження' });
  }
});

// отримати історію по полю
router.get('/', authenticate, async (req, res) => {
  const { fieldId, period = 7 } = req.query;
  if (!fieldId) return res.status(400).json({ error: 'Необхідно вказати fieldId' });

  const since = new Date(Date.now() - Number(period) * 24 * 60 * 60 * 1000);
  const readings = await SensorReading.find({
    fieldId,
    timestamp: { $gte: since }
  }).sort({ timestamp: 1 });

  res.json(readings);
});

export default router;
