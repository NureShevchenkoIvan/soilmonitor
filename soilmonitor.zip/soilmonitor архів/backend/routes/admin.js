import express from 'express';
import User from '../models/User.js';
import { deleteUser } from '../controllers/userController.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// лише для адміністраторів
const isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') return res.sendStatus(403);
  next();
};

router.get('/users', authenticate, isAdmin, async (req, res) => {
  const users = await User.find().select('-password');
  res.json(users);
});

router.delete('/users/:id', authenticate, isAdmin, deleteUser);

router.put('/users/:id/block', authenticate, isAdmin, async (req, res) => {
  const user = await User.findById(req.params.id);
  user.blocked = !user.blocked;
  await user.save();
  res.json({ blocked: user.blocked });
});

// оновлення користувача
router.put('/users/:id', authenticate, isAdmin, async (req, res) => {
  const user = await User.findById(req.params.id);
  const { name, email, role } = req.body;

  if (name) user.name = name;
  if (email) user.email = email;
  if (role && ['user', 'admin'].includes(role)) user.role = role;

  await user.save();
  res.json(user);
});

router.delete('/:id', authenticate, deleteUser);

export default router;
