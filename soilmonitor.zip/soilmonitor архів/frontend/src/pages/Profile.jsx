import React, { useEffect, useState } from "react";
import { Box, TextField, Button, Typography } from "@mui/material";
import API from "../services/api";

const Profile = () => {
  const [user, setUser] = useState({ name: "", email: "", phone: "", company: "" });
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");

  useEffect(() => {
    API.get("/auth/me").then((res) => {
      setUser(res.data);
    });
  }, []);

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    try {
      await API.put("/auth/me", {
        name: user.name,
        phone: user.phone,
        company: user.company,
      });
      alert("Дані оновлено!");
    } catch (e) {
      alert("Помилка при збереженні.");
    }
  };

  const handlePasswordChange = async () => {
    if (!currentPassword || !newPassword) {
      alert("Будь ласка, заповніть обидва поля.");
      return;
    }

    if (newPassword.length < 8) {
      alert("Новий пароль повинен містити щонайменше 8 символів.");
      return;
    }

    try {
      await API.put("/auth/me/password", {
        currentPassword,
        newPassword,
      });
      alert("Пароль змінено успішно!");
      setCurrentPassword("");
      setNewPassword("");
    } catch (e) {
      alert("Не вдалося змінити пароль: " + (e?.response?.data?.error || "Серверна помилка"));
    }
  };

  return (
    <Box sx={{ maxWidth: 600, mx: "auto" }}>
      <Typography variant="h4" gutterBottom>Профіль</Typography>

      <TextField
        label="Ім'я"
        name="name"
        value={user.name}
        onChange={handleChange}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Email"
        name="email"
        value={user.email}
        disabled
        fullWidth
        margin="normal"
      />
      <TextField
        label="Телефон"
        name="phone"
        value={user.phone}
        onChange={handleChange}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Компанія / господарство"
        name="company"
        value={user.company}
        onChange={handleChange}
        fullWidth
        margin="normal"
      />

      <Button variant="contained" onClick={handleSave} sx={{ mt: 2 }}>
        Зберегти
      </Button>

      <Typography variant="h6" sx={{ mt: 4 }}>
        Зміна паролю
      </Typography>

      <TextField
        label="Поточний пароль"
        type="password"
        value={currentPassword}
        onChange={(e) => setCurrentPassword(e.target.value)}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Новий пароль"
        type="password"
        value={newPassword}
        onChange={(e) => setNewPassword(e.target.value)}
        fullWidth
        margin="normal"
      />

      <Button variant="outlined" onClick={handlePasswordChange} sx={{ mt: 2 }}>
        Змінити пароль
      </Button>
    </Box>
  );
};

export default Profile;