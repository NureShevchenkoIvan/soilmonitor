import React, { useEffect, useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';

const typeColors = {
  Полив: '#69c',
  Добрива: '#9c6',
  Обробка: '#c96',
  Інше: '#aaa',
};

export default function TaskCalendar() {
  const [tasks, setTasks] = useState([]);
  const [fields, setFields] = useState([]);
  const [form, setForm] = useState({
    title: '',
    type: 'Полив',
    fieldId: '',
    date: '',
    description: '',
    priority: 'середній',
  });

  const fetchFields = async () => {
    const res = await fetch('http://localhost:5000/api/fields', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    const data = await res.json();
    setFields(data);
  };

  const fetchTasks = async () => {
    const res = await fetch('http://localhost:5000/api/tasks', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    const data = await res.json();
    setTasks(data);
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const addTask = async () => {
    const res = await fetch('http://localhost:5000/api/tasks', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify(form),
    });
    if (res.ok) fetchTasks();
  };

  const markDone = async (id) => {
    const res = await fetch(`http://localhost:5000/api/tasks/${id}/status`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    if (res.ok) fetchTasks();
  };

  const deleteTask = async (id) => {
    if (!window.confirm("Видалити цю задачу?")) return;
    const res = await fetch(`http://localhost:5000/api/tasks/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    if (res.ok) fetchTasks();
  };

  useEffect(() => {
    fetchFields();
    fetchTasks();
  }, []);

  const events = tasks.map((task) => ({
    id: task._id,
    title: `${task.title} (${task.type})`,
    start: task.date,
    color: typeColors[task.type] || '#888',
  }));

  const handleEventClick = (info) => {
    const task = tasks.find(t => t._id === info.event.id);
    const field = fields.find(f => f._id === task?.fieldId);
    if (task) {
        alert(`📌 ${task.title}
        Тип: ${task.type}
        Поле: ${field?.name || "невідомо"}
        Пріоритет: ${task.priority}
        Опис: ${task.description}
        Статус: ${task.status}`);
    }
  };

  return (
    <div>
      <h2>🗓 Календар агротехнічних робіт</h2>
      <h4>Додати нову задачу:</h4>
      <input placeholder="Назва" name="title" onChange={handleChange} />
      <select name="type" value={form.type} onChange={handleChange}>
        <option>Полив</option>
        <option>Добрива</option>
        <option>Обробка</option>
        <option>Інше</option>
      </select>
      <select name="fieldId" value={form.fieldId} onChange={handleChange}>
        <option value="">-- Оберіть поле --</option>
        {fields.map((f) => (
          <option key={f._id} value={f._id}>
            {f.name}
          </option>
        ))}
      </select>
      <input type="date" name="date" onChange={handleChange} />
      <input placeholder="Опис" name="description" onChange={handleChange} />
      <select name="priority" value={form.priority} onChange={handleChange}>
        <option>низький</option>
        <option>середній</option>
        <option>високий</option>
      </select>
      <button onClick={addTask}>Зберегти</button>

      <h4>Список задач:</h4>
      <ul>
        {tasks.map((t) => (
          <li key={t._id}>
            📌 {t.title} | {new Date(t.date).toLocaleDateString()} | {t.type} | {t.status}
            {t.status === 'заплановано' && <button onClick={() => markDone(t._id)}>Позначити як виконано</button>}
            <button onClick={() => deleteTask(t._id)}>❌ Видалити</button>
          </li>
        ))}
      </ul>

      <FullCalendar
        plugins={[dayGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        locale="uk"
        events={events}
        eventClick={handleEventClick}
        height="auto"
      />
    </div>
  );
}