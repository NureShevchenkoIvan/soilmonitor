import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  MapContainer,
  TileLayer,
  Polygon,
  useMapEvents,
} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  DialogActions,
  MenuItem,
  Card,
  CardContent,
  Typography,
  Grid,
  Select,
  InputLabel,
  FormControl,
} from "@mui/material";
import SensorsIcon from "@mui/icons-material/Sensors";
import WarningIcon from "@mui/icons-material/Warning";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";

export default function Dashboard() {
  const [fields, setFields] = useState([]);
  const [sensors, setSensors] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [open, setOpen] = useState(false);
  const [filterCrop, setFilterCrop] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [newField, setNewField] = useState({
    name: "",
    crop: "",
    sowingDate: "",
    boundary: [],
  });

  const navigate = useNavigate();

  const fetchFields = async () => {
    const res = await fetch("http://localhost:5000/api/fields/with-stats", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    const data = await res.json();
    setFields(data);
  };

  const fetchSensors = async () => {
    const res = await fetch("http://localhost:5000/api/sensors", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    const data = await res.json();
    setSensors(data);
  };

  const fetchTasks = async () => {
    const res = await fetch("http://localhost:5000/api/tasks/upcoming?days=3", {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
    const data = await res.json();
    setTasks(data);
  };

  useEffect(() => {
    fetchFields();
    fetchSensors();
    fetchTasks();
  }, []);

  const center = fields.length
    ? [fields[0].boundary[0].lat, fields[0].boundary[0].lng]
    : [49.84, 24.03];

  const handleMapClick = (e) => {
    const { lat, lng } = e.latlng;
    const boundary = [...newField.boundary, { lat, lng }];

    const isClosed =
      boundary.length >= 3 &&
      Math.abs(boundary[0].lat - lat) < 0.0005 &&
      Math.abs(boundary[0].lng - lng) < 0.0005;

    setNewField({
      ...newField,
      boundary: isClosed ? [...boundary, boundary[0]] : boundary,
    });

    if (isClosed) {
      alert("Поле замкнено. Тепер можна зберегти.");
    }
  };

  function ClickHandler() {
    useMapEvents({
      click: handleMapClick,
    });
    return null;
  }

  const handleSave = async () => {
    const res = await fetch("http://localhost:5000/api/fields", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify(newField),
    });
    if (res.ok) {
      setOpen(false);
      setNewField({ name: "", crop: "", sowingDate: "", boundary: [] });
      fetchFields();
    }
  };

  const filteredFields = fields.filter((f) => {
    return (
      (!filterCrop || f.crop === filterCrop) &&
      (!filterStatus || f.status === filterStatus)
    );
  });

  const criticalFields = fields.filter((f) => f.status === "критичний");

  return (
    <div style={{ padding: "1rem" }}>
      <Typography variant="h4" gutterBottom>Головна сторінка</Typography>

      {/* Інформаційні картки */}
      <Grid container spacing={2} marginBottom={2}>
        <Grid>
          <Card>
            <CardContent>
              <Typography variant="h6"><SensorsIcon /> Активні сенсори</Typography>
              <Typography variant="h4">{sensors.length}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid>
          <Card>
            <CardContent>
              <Typography variant="h6"><WarningIcon /> Поля з критичними показниками</Typography>
              <Typography variant="h4">{criticalFields.length}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid>
          <Card>
            <CardContent>
              <Typography variant="h6"><CalendarMonthIcon /> Роботи на 3 дні</Typography>
              <ul>
                {tasks.map((t) => (
                  <li key={t._id}>{new Date(t.date).toLocaleDateString("uk-UA")}: {t.title}</li>
                ))}
              </ul>
              <Button size="small" onClick={() => navigate("/calendar")}>До календаря</Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Фільтри */}
      <Grid container spacing={2} marginBottom={2}>
        <Grid>
          <FormControl fullWidth>
            <InputLabel>Культура</InputLabel>
            <Select value={filterCrop} label="Культура" onChange={(e) => setFilterCrop(e.target.value)}>
              <MenuItem value="">Усі</MenuItem>
              <MenuItem value="пшениця">пшениця</MenuItem>
              <MenuItem value="кукурудза">кукурудза</MenuItem>
              <MenuItem value="соняшник">соняшник</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid>
          <FormControl fullWidth>
            <InputLabel>Стан</InputLabel>
            <Select value={filterStatus} label="Стан" onChange={(e) => setFilterStatus(e.target.value)}>
              <MenuItem value="">Усі</MenuItem>
              <MenuItem value="нормальний">нормальний</MenuItem>
              <MenuItem value="потребує уваги">потребує уваги</MenuItem>
              <MenuItem value="критичний">критичний</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      {/* Мапа */}
      <MapContainer center={center} zoom={14} style={{ height: "400px", width: "100%" }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {filteredFields.map((f, i) => (
          <Polygon
            key={i}
            positions={f.boundary.map((p) => [p.lat, p.lng])}
            color={
              f.status === "критичний"
                ? "red"
                : f.status === "потребує уваги"
                ? "orange"
                : "green"
            }
          />
        ))}
      </MapContainer>

      {/* Кнопка додавання */}
      <div style={{ marginTop: "1rem" }}>
        <Button variant="contained" onClick={() => setOpen(true)}>
          ➕ Додати поле
        </Button>
      </div>

      {/* Список полів */}
      <h3>Список полів</h3>
      <ul>
        {filteredFields.map((f) => (
          <li key={f._id}>
            🌾 <strong>{f.name}</strong> ({f.crop}) — {f.status || "нормальний"} | 🌡 {f.avgTemperature?.toFixed(1) ?? "--"}°C | 💧 {f.avgHumidity?.toFixed(1) ?? "--"}% | 🧪 {f.avgNPK?.toFixed(1) ?? "--"}
            &nbsp;
            <Button onClick={() => navigate(`/field/${f._id}`)}>Детальніше</Button>
          </li>
        ))}
      </ul>

      {/* Діалогове вікно додавання поля */}
      <Dialog open={open} onClose={() => setOpen(false)} fullWidth>
        <DialogTitle>Додати поле</DialogTitle>
        <DialogContent>
          <p>Натисніть на мапу, щоб визначити межі поля.</p>
          <MapContainer center={center} zoom={14} style={{ height: "300px", width: "100%" }}>
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <ClickHandler />
            {newField.boundary.length > 0 && (
              <Polygon positions={newField.boundary.map((p) => [p.lat, p.lng])} color="blue" />
            )}
          </MapContainer>
          <TextField
            margin="dense"
            label="Назва поля"
            fullWidth
            value={newField.name}
            onChange={(e) => setNewField({ ...newField, name: e.target.value })}
          />
          <TextField
            margin="dense"
            label="Культура"
            fullWidth
            select
            value={newField.crop}
            onChange={(e) => setNewField({ ...newField, crop: e.target.value })}
          >
            <MenuItem value="пшениця">пшениця</MenuItem>
            <MenuItem value="кукурудза">кукурудза</MenuItem>
            <MenuItem value="соняшник">соняшник</MenuItem>
          </TextField>
          <TextField
            margin="dense"
            label="Дата посіву"
            type="date"
            fullWidth
            InputLabelProps={{ shrink: true }}
            value={newField.sowingDate}
            onChange={(e) => setNewField({ ...newField, sowingDate: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setOpen(false);
            setNewField({ name: "", crop: "", sowingDate: "", boundary: [] });
          }}>
            Скасувати
          </Button>
          <Button onClick={handleSave} disabled={newField.boundary.length < 4 || !newField.name}>
            Зберегти
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}