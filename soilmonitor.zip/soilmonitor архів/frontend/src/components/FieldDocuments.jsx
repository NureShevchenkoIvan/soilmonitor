import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function FieldDocuments({ fieldId }) {
  const [documents, setDocuments] = useState([]);
  const [file, setFile] = useState(null);

  const fetchDocuments = async () => {
    const res = await axios.get(`http://localhost:5000/api/fields/${fieldId}/documents`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
    });
    setDocuments(res.data);
  };

  const uploadDocument = async () => {
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    await axios.post(`http://localhost:5000/api/fields/${fieldId}/upload`, formData, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`,
        'Content-Type': 'multipart/form-data',
      },
    });
    setFile(null);
    fetchDocuments();
  };

  const deleteDocument = async (docId) => {
    if (!window.confirm("Ви впевнені, що хочете видалити документ?")) return;
    await axios.delete(`http://localhost:5000/api/fields/${fieldId}/documents/${docId}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    fetchDocuments();
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  return (
    <div style={{ marginTop: '2rem' }}>
      <h3>📂 Документи</h3>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={uploadDocument}>📤 Завантажити</button>
      <ul>
        {documents.map((doc) => (
          <li key={doc._id}>
            <a href={doc.url} target="_blank" rel="noopener noreferrer">{doc.filename}</a>
            <button onClick={() => deleteDocument(doc._id)}>🗑️</button>
          </li>
        ))}
      </ul>
    </div>
  );
}