import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Polygon, Marker, useMapEvents } from 'react-leaflet';
import { Button, Dialog, DialogTitle, DialogContent, TextField, DialogActions, List, ListItem, ListItemText } from '@mui/material';
import 'leaflet/dist/leaflet.css';

const FieldForm = ({ open, onClose, onSave, polygon }) => {
  const [form, setForm] = useState({ name: '', crop: '', sowingDate: '' });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = () => {
    onSave({ ...form, boundary: polygon });
    setForm({ name: '', crop: '', sowingDate: '' });
  };

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogTitle>Додати поле</DialogTitle>
      <DialogContent>
        <TextField margin="dense" label="Назва поля" name="name" fullWidth onChange={handleChange} />
        <TextField margin="dense" label="Культура" name="crop" fullWidth onChange={handleChange} />
        <TextField margin="dense" type="date" name="sowingDate" fullWidth onChange={handleChange} InputLabelProps={{ shrink: true }} />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Скасувати</Button>
        <Button onClick={handleSubmit}>Зберегти</Button>
      </DialogActions>
    </Dialog>
  );
};

const ClickHandler = ({ onClickPoint }) => {
  useMapEvents({
    click(e) {
      onClickPoint([e.latlng.lat, e.latlng.lng]);
    },
  });
  return null;
};

export default function MapFieldCreator({ onFieldCreated }) {
  const [points, setPoints] = useState([]);
  const [polygonClosed, setPolygonClosed] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [fields, setFields] = useState([]);

  const handleClickPoint = (point) => {
    if (polygonClosed) return;
    if (points.length > 2) {
      const [firstLat, firstLng] = points[0];
      const [lat, lng] = point;
      const dist = Math.sqrt((lat - firstLat) ** 2 + (lng - firstLng) ** 2);
      if (dist < 0.0005) {
        setPolygonClosed(true);
        setFormOpen(true);
        return;
      }
    }
    setPoints([...points, point]);
  };

  const handleSaveField = async (fieldData) => {
    try {
      const res = await fetch('http://localhost:5000/api/fields', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(fieldData),
      });
      if (res.ok) {
        setPoints([]);
        setPolygonClosed(false);
        setFormOpen(false);
        fetchFields();
        onFieldCreated();
      }
    } catch (error) {
      console.error('Помилка при збереженні поля:', error);
    }
  };

  const fetchFields = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/fields', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
      });
      const data = await res.json();
      setFields(data);
    } catch (error) {
      console.error('Не вдалося завантажити поля:', error);
    }
  };

  useEffect(() => {
    fetchFields();
  }, []);

  return (
    <div style={{ display: 'flex', gap: '1rem' }}>
      <div style={{ flex: 2 }}>
        <MapContainer center={[49.842957, 24.031111]} zoom={13} style={{ height: '500px', width: '100%' }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <ClickHandler onClickPoint={handleClickPoint} />

          {/* Нове поле */}
          {points.length > 0 && <Polygon positions={points} color="green" />} 
          {points.map((pos, i) => <Marker key={`new-${i}`} position={pos} />)}

          {/* Існуючі поля */}
          {fields.map((field, idx) => (
            <Polygon key={`f-${idx}`} positions={field.boundary.map(p => [p.lat, p.lng])} color="blue" />
          ))}
        </MapContainer>
        <FieldForm open={formOpen} onClose={() => setFormOpen(false)} onSave={handleSaveField} polygon={points.map(([lat, lng]) => ({ lat, lng }))} />
      </div>

      <div style={{ flex: 1 }}>
        <h3>Ваші поля</h3>
        <List>
          {fields.map((field) => (
            <ListItem key={field._id} divider>
              <ListItemText primary={field.name} secondary={field.crop} />
              <Button href={`/field/${field._id}`} variant="outlined" size="small">Детальніше</Button>
            </ListItem>
          ))}
        </List>
      </div>
    </div>
  );
}
